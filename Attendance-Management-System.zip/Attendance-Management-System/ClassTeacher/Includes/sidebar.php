 <ul class="navbar-nav sidebar sidebar-light accordion" id="accordionSidebar">
   <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php" style="background-color: #6777EF;">
     <div class="sidebar-brand-icon">
       <img src="img/logo/admin_logo.png">
     </div>
     <div class="sidebar-brand-text mx-3">AMS</div>
   </a>
   <hr class="sidebar-divider my-0">
   <li class="nav-item active">
     <a class="nav-link" href="index.php">
       <i class="fas fa-fw fa-tachometer-alt"></i>
       <span>Dashboard</span></a>
   </li>
   <hr class="sidebar-divider">
   <div class="sidebar-heading text-dark"  style="font-size: medium;">
     Students
   </div>
   </li>
   <li class="nav-item">
     <a class="nav-link collapsed text-dark" href="#" data-toggle="collapse" data-target="#collapseBootstrap2"
       aria-expanded="true" aria-controls="collapseBootstrap2"  style="font-size: larger;">
       <i class="fas fa-user-graduate"></i>
       <span>Manage Students</span>
     </a>
     <div id="collapseBootstrap2" class="collapse" aria-labelledby="headingBootstrap" data-parent="#accordionSidebar">
       <div class="bg-white py-2 collapse-inner rounded">
         <a class="collapse-item text-dark" href="viewStudents.php"  style="font-size: medium;">View Students</a>
         <!-- <a class="collapse-item" href="#">Assets Type</a> -->
       </div>
     </div>
   </li>
   <hr class="sidebar-divider">
   <div class="sidebar-heading text-dark"   style="font-size: medium;">
     Attendance
   </div>
   </li>
   <li class="nav-item">
     <a class="nav-link collapsed text-dark" href="#" data-toggle="collapse" data-target="#collapseBootstrapcon"
       aria-expanded="true" aria-controls="collapseBootstrapcon"  style="font-size: larger;">
       <i class="fa fa-calendar-alt"></i>
       <span>Manage Attendance</span>
     </a>
     <div id="collapseBootstrapcon" class="collapse" aria-labelledby="headingBootstrap" data-parent="#accordionSidebar">
       <div class="bg-white py-2 collapse-inner rounded">
         <a class="collapse-item text-dark" href="takeAttendance.php"  style="font-size: medium;">Take Attendance</a>
         <a class="collapse-item text-dark" href="viewAttendance.php"  style="font-size: medium;">View Class Attendance</a>
         <a class="collapse-item text-dark" href="downloadRecord.php" style="font-size: medium;">Today's Report (xls)</a>
         <!-- <a class="collapse-item" href="addMemberToContLevel.php ">Add Member to Level</a> -->
       </div>
     </div>
   </li>
   <hr class="sidebar-divider">

 </ul>